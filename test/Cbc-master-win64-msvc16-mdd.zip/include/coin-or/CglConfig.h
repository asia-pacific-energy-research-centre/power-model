/* src/CglCommon/config_cgl.h.  Generated from config_cgl.h.in by configure.  */
/* src/config_cgl.h.in. */

#ifndef __CONFIG_CGL_H__
#define __CONFIG_CGL_H__

/* Version number of project */
#define CGL_VERSION "devel"

/* Major Version number of project */
#define CGL_VERSION_MAJOR 9999

/* Minor Version number of project */
#define CGL_VERSION_MINOR 9999

/* Release Version number of project */
#define CGL_VERSION_RELEASE 9999

/* Library Visibility Attribute */
#define CGLLIB_EXPORT __declspec(dllimport)

#endif
