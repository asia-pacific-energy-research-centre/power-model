/* src/OsiCommonTest/config_osicommontest.h.  Generated from config_osicommontest.h.in by configure.  */
/* src/Osi/config_osicommontest.h.in. */

#ifndef __CONFIG_OSICOMMONTEST_H__
#define __CONFIG_OSICOMMONTEST_H__

/* Library Visibility Attribute */
#define OSICOMMONTESTLIB_EXPORT __declspec(dllimport)

#endif
