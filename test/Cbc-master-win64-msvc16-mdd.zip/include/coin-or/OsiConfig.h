/* src/Osi/config_osi.h.  Generated from config_osi.h.in by configure.  */
/* src/Osi/config_osi.h.in. */

#ifndef __CONFIG_OSI_H__
#define __CONFIG_OSI_H__

/* Library Visibility Attribute */
#define OSILIB_EXPORT __declspec(dllimport)

/* Version number of project */
#define OSI_VERSION "devel"

/* Major Version number of project */
#define OSI_VERSION_MAJOR 9999

/* Minor Version number of project */
#define OSI_VERSION_MINOR 9999

/* Release Version number of project */
#define OSI_VERSION_RELEASE 9999

#endif
