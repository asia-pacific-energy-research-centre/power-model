/* src/OsiClp/config_osiclp.h.  Generated from config_osiclp.h.in by configure.  */
/* src/config_osiclp.h.in.  */

#ifndef __CONFIG_OSICLP_H__
#define __CONFIG_OSICLP_H__

/* Library Visibility Attribute */
#define OSICLPLIB_EXPORT __declspec(dllimport)

#endif
